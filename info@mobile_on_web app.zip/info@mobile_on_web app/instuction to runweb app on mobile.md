# 📱 Flask File Share on Android (Termux)

This guide explains how to run a Flask-based local file sharing server directly on your Android device using Termux.

---

## 🚀 Setup Instructions

### 1. Install Termux
Download Termux from the Google Play Store.

### 2. Update Termux Packages
pkg update && pkg upgrade

### 3. Install Python
pkg install python

### 4. Verify Python Installation
python --version

### 5. Enable Storage Access
termux-setup-storage

### 6. Navigate to Project Directory
cd "/storage/emulated/0/Download/Passed local file share-ip privacy"

### 7. List Files
ls

### 8. Install Project Requirements
pip install -r requirements.txt

---

## 📝 Create a Shell Script

### 9. Create start_server.sh
nano start_server.sh

Paste the following:
#!/bin/bash
# Navigate to your project directory
cd "/storage/emulated/0/Download/Passed local file share-ip privacy"

# Run the Flask server
python app.py

### 10. Make Script Executable
chmod +x start_server.sh

### 11. Run the Script
./start_server.sh

---

## ⚡ Add Alias for Easy Start

### 12. Edit Bash Configuration
nano ~/.bashrc

Add this line at the end:
alias start_server="~/start_server.sh"

### 13. Reload Bash Configuration
source ~/.bashrc

### 14. Start Server with Alias
start_server

---

## ✅ Result
- Flask server will start on http://127.0.0.1:5000
- Accessible via your device’s browser or other devices on the same Wi-Fi using your local IP (e.g., http://192.168.x.x:5000).
- First connected device becomes Admin. Admin can see all IPs, others can only see their own.

---

## ⚠️ Notes
- This setup is for development/testing only.
- Do not expose directly to the internet without tunneling tools (ngrok, localtunnel, cloudflared).
- For production, use a proper WSGI server (e.g., Gunicorn) instead of Flask’s built-in server.